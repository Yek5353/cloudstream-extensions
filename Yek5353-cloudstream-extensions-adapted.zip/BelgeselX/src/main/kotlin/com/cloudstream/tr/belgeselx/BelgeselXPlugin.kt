package com.cloudstream.tr.belgeselx

import com.lagradost.cloudstream3.plugins.BasePlugin
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin

@CloudstreamPlugin
class BelgeselXPlugin : BasePlugin() {
    override fun load() {
        registerMainAPI(BelgeselX())
    }
}
